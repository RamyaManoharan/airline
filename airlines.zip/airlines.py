import json
file =  open('C://Users//Ramya//Downloads//airlines.csv','r') .readlines()
output_1 = {}
file.pop(0)
for line in file:
    
    l1 = line.split(',')
    code, name_1, name_2, year, cancelled = l1
    name = name_1 + "," + name_2
    name = name.replace('"','')

    if name in output_1.keys():
        count = output_1[name]
        count = count+1
        output_1.update({name:count})
    else:
        output_1.update({name:1})

maximum = max(output_1.keys(), key = (lambda k: output_1[k])  )
minimum = min(output_1.keys(), key = (lambda k: output_1[k])   )  

##### JSON format ######
print(json.dumps(output_1,indent = 4))
##### Maximum ######
print("Maximum:", maximum, output_1[maximum] )
##### Minimum ######
print("Minimum:", minimum, output_1[minimum] )


